# Change Log

## [1.1.1] 2020-06-26
- Package updates

## [1.1.0] 2019-02-12
- Package updates
- Add pwa support
- Improve accessibility
- Cleanups & other minor UI improvements
- Improve bundle size

## [1.0.1] 2018-12-03
### Minor updates
- Upgrade packages
- Change sidebar gradient colors (more pleasant)
- Make links "bolder" in the sidebar so they are more readable
- Improve bundle size, add vue-router prefetch
- Add pwa support


## [1.0.0] 2018-10-14
### Stable Original Release
